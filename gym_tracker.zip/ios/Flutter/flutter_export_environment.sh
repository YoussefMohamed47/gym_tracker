#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\Encooders\.shorebird\bin\cache\flutter\65b1e4368e98a85ea11e8ef2cffc286c3b2ad8b2"
export "FLUTTER_APPLICATION_PATH=D:\gym_tracker"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=D:\gym_tracker\ios\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.1.0"
export "FLUTTER_BUILD_NUMBER=2"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
